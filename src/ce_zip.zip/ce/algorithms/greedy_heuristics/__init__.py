from ce.algorithms.greedy_heuristics.greedy_cycle import greedy_cycle
from ce.algorithms.greedy_heuristics.nearest_neighbor import nearest_neighbor
from ce.algorithms.greedy_heuristics.random_solution import random_solution
